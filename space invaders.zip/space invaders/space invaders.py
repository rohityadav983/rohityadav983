import pygame 
import random
import math
from pygame import mixer

pygame.init()
screen = pygame.display.set_mode((800, 600))

pygame.display.set_caption('Space Invaders')
background = pygame.image.load('247.jpg')
mixer.music.load('background.wav')
mixer.music.play(-1)
icon = pygame.image.load('sport.png')
pygame.display.set_icon(icon)

# player
playerimg = pygame.image.load('sport1.png')
playerx = 370
playery = 480
playerx_c = 0

# enemy
enemyimg = []
enemyx = []
enemyy = []
enemyx_c = []
enemyy_c = []
nofen = 6
for i in range(nofen):
    enemyimg.append(pygame.image.load('alien.png'))
    enemyx.append(random.randint(0, 735))
    enemyy.append(random.randint(50, 150))
    enemyx_c.append(1)
    enemyy_c.append(40)

# bullet
bulletimg = pygame.image.load('bullet.png')
bulletx = 0
bullety = 480
bulletx_c = 0
bullety_c = 10
bullet_state = 'ready'

# score
scoreval = 0
font = pygame.font.Font('freesansbold.ttf', 32)
textx = 10
texty = 10

ofont = pygame.font.Font('freesansbold.ttf', 64)

def showscr(x,y):
    score = font.render('SCORE :' + str(scoreval), True, (255, 255, 255))
    screen.blit(score, (x, y))

def gameotxt():
    otxt = ofont.render('GAME OVER', True, (255, 255, 255))
    screen.blit(otxt, (200, 250))

def player(x, y):
    screen.blit(playerimg, (x, y))


def enemy(x, y, i):
    screen.blit(enemyimg[i], (x, y))


def bullet(x, y):
    global bullet_state
    bullet_state = "fire"
    screen.blit(bulletimg, (x + 16, y + 10))


def iscollision(enemyx, enemyy, bulletx, bullety):
    distance = math.sqrt((math.pow(enemyx - bulletx, 2)) + (math.pow(enemyy - bullety, 2)))
    if distance < 27:
        return True
    else:
        return False


running = True
# game loop
while running:
    screen.fill((0, 0, 0))
    screen.blit(background, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerx_c = -2

            if event.key == pygame.K_RIGHT:
                playerx_c = 2

            if event.key == pygame.K_SPACE:
                if bullet_state == 'ready':
                    bullso = mixer.Sound('laser.wav')
                    bullso.play()
                    bulletx = playerx
                    bullet(playerx, bullety)

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerx_c = 0

    playerx += playerx_c

    if playerx <= 0:
        playerx = 0
    elif playerx >= 736:
        playerx = 736

    for i in range(nofen):
        if enemyy[i] > 420:
            for j in range(nofen):
                enemyy[i] = 2000
                gameotxt()
                break

        enemyx[i] += enemyx_c[i]
        if enemyx[i] <= 0:
            enemyx_c[i] = 1
            enemyy[i] += enemyy_c[i]
        elif enemyx[i] >= 736:
            enemyx_c[i] = -1
            enemyy[i] += enemyy_c[i]

        collision = iscollision(enemyx[i], enemyy[i], bulletx, bullety)
        if collision:
            collso = mixer.Sound('explosion.wav')
            collso.play()
            bullety = 480
            bullet_state = 'ready'
            scoreval += 1
            enemyx[i] = random.randint(0, 735)
            enemyy[i] = random.randint(50, 150)
        enemy(enemyx[i], enemyy[i], i)

    if bullety <= 0:
        bullety = 480
        bullet_state = 'ready'

    if bullet_state == 'fire':
        bullet(bulletx, bullety)
        bullety -= bullety_c

    player(playerx, playery)
    showscr(textx, texty)
    pygame.display.update()
